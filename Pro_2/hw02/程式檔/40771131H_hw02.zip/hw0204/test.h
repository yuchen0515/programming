#pragma once
#include <stdint.h>

int32_t fibonacci(int32_t n);
int32_t factorial(int32_t n);
