#include <stdio.h>
#include <stdint.h>

int main(int32_t argc, char *argv[]){
	printf("Hello, I'm Linux Lin!\n");

	return 0;
}
